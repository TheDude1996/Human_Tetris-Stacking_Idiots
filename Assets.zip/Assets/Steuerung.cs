using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Steuerung : MonoBehaviour
{
    public Vector3 rotationPoint;
    private float previousTime;
    public float fallTime = 0.8f;

    // Grid Definition
    public static int height = 160;
    public static int width = 44;
    public static Transform[,] grid = new Transform[width, height];

    void Start()
    {
        previousTime = Time.time;
    }

    void Update()
    {
        // --- Bewegung Links/Rechts ---
        if (Input.GetKeyDown(KeyCode.RightArrow))
        {
            transform.position += new Vector3(4, 0, 0);
            if (!ValidMove()) transform.position -= new Vector3(4, 0, 0);
        }
        else if (Input.GetKeyDown(KeyCode.LeftArrow))
        {
            transform.position += new Vector3(-4, 0, 0);
            if (!ValidMove()) transform.position -= new Vector3(-4, 0, 0);
        }
        // --- Rotation ---
        else if (Input.GetKeyDown(KeyCode.UpArrow))
        {
            transform.RotateAround(transform.TransformPoint(rotationPoint), new Vector3(0, 0, 1), 90);
            if (!ValidMove()) transform.RotateAround(transform.TransformPoint(rotationPoint), new Vector3(0, 0, 1), -90);
        }

        // --- Fallen ---
        if (Time.time - previousTime > (Input.GetKey(KeyCode.DownArrow) ? fallTime / 10 : fallTime))
        {
            transform.position += new Vector3(0, -4, 0);

            if (!ValidMove())
            {
                // Kollision: Zur�ckbewegen
                transform.position -= new Vector3(0, -4, 0);

                // WICHTIG: Block ins Grid eintragen
                AddToGrid();

                // Skript deaktivieren & neuen spawnen
                this.enabled = false;
                FindObjectsByType<SpawnTetromino>(FindObjectsSortMode.None)[0].NewTetromino();
            }
            else
            {
                // Erfolgreich gefallen: Timer resetten
                previousTime = Time.time;
            }
        }
    }

    // 1. Die Speicher-Funktion (fehlt noch in deinem Code)
    void AddToGrid()
    {
        foreach (Transform child in transform)
        {
            int x = Mathf.RoundToInt(child.position.x);
            int y = Mathf.RoundToInt(child.position.y);

            if (x >= 0 && x < width && y >= 0 && y < height)
            {
                grid[x, y] = child; // Hier wird der Block "festgeschrieben"
            }
        }
    }

    // 2. Die Pr�ffunktion (muss das Grid abfragen!)
    bool ValidMove()
    {
        foreach (Transform child in transform)
        {
            int x = Mathf.RoundToInt(child.position.x);
            int y = Mathf.RoundToInt(child.position.y);

            // A) Grenzen pr�fen
            if (x < 0 || x >= width || y < 0 || y >= height)
            {
                return false;
            }

            // B) Kollision mit anderen Bl�cken pr�fen (FEHLTE NOCH!)
            if (grid[x, y] != null)
            {
                return false;
            }
        }
        return true;
    }
}